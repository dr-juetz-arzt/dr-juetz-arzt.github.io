# Praxis Dr. med. Martin Jütz – Facharzt für Allgemeinmedizin, Berlin

Willkommen auf der offiziellen GitHub Pages-Seite der Praxis Dr. med. Martin Jütz. Diese Website ist vollständig statisch, DSGVO-konform, barrierearm und frei von Cookies oder Trackern.

## Inhalte

- `index.html`: Startseite mit Praxisinformationen
- `impressum.html`: Gesetzliches Impressum
- `datenschutz.html`: Datenschutzerklärung
- `Cross.png`: Praxislogo
- `README.md`: Diese Projektdokumentation

## Hosting

Diese Website kann über GitHub Pages gehostet werden. Einfach den Branch veröffentlichen und GitHub Pages aktivieren.

## Lizenz

MIT – frei nutzbar für medizinische Praxis-Websites ohne Gewähr.
